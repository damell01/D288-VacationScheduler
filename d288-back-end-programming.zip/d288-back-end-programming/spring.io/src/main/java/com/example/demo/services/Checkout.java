package com.example.demo.services;

public interface Checkout
{
    PurchaseReply placeOrder(Purchase purchase);
}