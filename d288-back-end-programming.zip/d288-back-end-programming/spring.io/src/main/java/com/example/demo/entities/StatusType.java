package com.example.demo.entities;

public enum StatusType {
    pending,ordered,cancelled ;
}
