package com.example.demo;

import com.example.demo.dao.CountryRepository;
import com.example.demo.dao.CustomerRepository;
import com.example.demo.dao.DivisionRepository;
import com.example.demo.entities.Country;
import com.example.demo.entities.Customer;
import com.example.demo.entities.Division;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner
{
    private final CustomerRepository customerRepository;
    private final DivisionRepository divisionRepository;
    private final CountryRepository countryRepository;

    public BootStrapData(CustomerRepository customerRepository, DivisionRepository divisionRepository, CountryRepository countryRepository)
    {
        this.customerRepository = customerRepository;
        this.divisionRepository = divisionRepository;
        this.countryRepository = countryRepository;
    }

    @Override
    public void run(String... args) throws Exception
    {
        //If there are more customers in the db than the default one (John doe) Skip
        if(customerRepository.count() > 1)
        {
            return;
        }

        Customer Damell = new Customer();
        Damell.setFirstName("Damell");
        Damell.setLastName("Bell");
        Damell.setAddress("866 Apple Road");
        Damell.setPostal_code("60606");
        Damell.setPhone("2714375982");

        Customer blake = new Customer();
        blake.setFirstName("Blake");
        blake.setLastName("Cashapp");
        blake.setAddress("100 Santa Street");
        blake.setPostal_code("30329");
        blake.setPhone("4043890913");

        Customer Santa = new Customer();
        Santa.setFirstName("Santa");
        Santa.setLastName("Claus");
        Santa.setAddress("2257 North Pole");
        Santa.setPostal_code("12345");
        Santa.setPhone("3369064314");

        Customer jerald = new Customer();
        jerald.setFirstName("Jerald");
        jerald.setLastName("Kendrick");
        jerald.setAddress("580 Fidler Drive");
        jerald.setPostal_code("78221");
        jerald.setPhone("2106272691");


        Customer clara = new Customer();
        clara.setFirstName("Clara");
        clara.setLastName("Whitfield");
        clara.setAddress("2887 Maloy Court");
        clara.setPostal_code("66425");
        clara.setPhone("7854671831");

        customerRepository.save(Damell);
        customerRepository.save(blake);
        customerRepository.save(Santa);
        customerRepository.save(jerald);
        customerRepository.save(clara);

        customerRepository.findAll();
    }
}
