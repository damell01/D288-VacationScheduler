package com.example.demo.services;

import lombok.Data;

@Data
public class PurchaseReply
{

    private final String orderTrackingNumber;
}